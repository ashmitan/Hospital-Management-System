/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.MedicalEquipmentSupplier;

import java.util.ArrayList;

/**
 *
 * @author Ashmita
 */
public class MedicalEquipmentSupplierDirectory {

    ArrayList<MedicalEquipmentSupplier> supplierList;
    
    public MedicalEquipmentSupplierDirectory() {
        supplierList = new ArrayList<MedicalEquipmentSupplier>();
        
    }
    
    
    
}
